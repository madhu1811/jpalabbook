package com.cg.pms.exception;

public class ProductException extends Exception {

	public ProductException(String message)
	{
		super(message);
	}
	
	public ProductException()
	{
		super();
	}
}
