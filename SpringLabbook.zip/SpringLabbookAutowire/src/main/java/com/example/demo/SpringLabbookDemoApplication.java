package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SpringLabbookDemoApplication {

	public static void main(String[] args) {
	 ConfigurableApplicationContext	ctx = SpringApplication.run(SpringLabbookDemoApplication.class, args);
	 
	 Employee emp = ctx.getBean(Employee.class);
	 SBU sbu = ctx.getBean(SBU.class);
	 
	 emp.setAge(20);
	 emp.setEmployeeId(1283);
	 emp.setEmployeeName("Madhurima");
	 emp.setSalary(40000);
	 
	 sbu.setSbuId(1280);
	 sbu.setSbuHead("Srujana");
	 sbu.setSbuName("PES");
	 
	 
	 System.out.println("Employee Details");
	 System.out.println("-------------------------");
	 System.out.println(emp.toString());
	}

}
