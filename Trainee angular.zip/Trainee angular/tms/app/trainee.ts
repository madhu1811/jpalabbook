export class Trainee{

    traineeId : number;
    traineeName : string;
    traineeLocation :string;
    traineeDomain : string; 

}