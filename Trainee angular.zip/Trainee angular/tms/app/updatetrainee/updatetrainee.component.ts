import { Component, OnInit } from '@angular/core';
import { Trainee } from '../trainee';
import { TraineeService } from '../trainee.service';

@Component({
  selector: 'app-updatetrainee',
  templateUrl: './updatetrainee.component.html',
  styleUrls: ['./updatetrainee.component.css']
})
export class UpdatetraineeComponent implements OnInit {

  arr : Trainee [] =[];
  trainee : Trainee = new Trainee();
  temp : Trainee = new Trainee();

  constructor(private service : TraineeService)
  {
    //service.getAllTrainees().subscribe( data =>this.arr=data);
    service.getAllTrainees().subscribe( data =>{this.arr = data.body;console.log(data);
    })
  }

  ngOnInit(): void {
  }

  updateTraineeById()
  {
    console.log(this.trainee);
    this.service.updateTraineeById(this.trainee).subscribe(data=>this.temp=data);
    this.service.getAllTrainees().subscribe( data => this.arr=data.body);
  }

}


