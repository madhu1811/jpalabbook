import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatetraineeComponent } from './updatetrainee.component';

describe('UpdatetraineeComponent', () => {
  let component: UpdatetraineeComponent;
  let fixture: ComponentFixture<UpdatetraineeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatetraineeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatetraineeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
