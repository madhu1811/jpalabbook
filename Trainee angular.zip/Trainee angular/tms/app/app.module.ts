import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddtraineeComponent } from './addtrainee/addtrainee.component';
import { ViewtraineeComponent } from './viewtrainee/viewtrainee.component';
import { SearchtraineeComponent } from './searchtrainee/searchtrainee.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { UpdatetraineeComponent } from './updatetrainee/updatetrainee.component';

@NgModule({
  declarations: [
    AppComponent,
    AddtraineeComponent,
    ViewtraineeComponent,
    SearchtraineeComponent,
    UpdatetraineeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
