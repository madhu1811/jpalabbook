import { Component, OnInit } from '@angular/core';
import { Trainee } from '../trainee';
import { TraineeService } from '../trainee.service';

@Component({
  selector: 'app-viewtrainee',
  templateUrl: './viewtrainee.component.html',
  styleUrls: ['./viewtrainee.component.css']
})
export class ViewtraineeComponent implements OnInit {

  arr : Trainee [] =[];
  traine : Trainee = new Trainee();
  constructor(private service : TraineeService)
  {
    //service.getAllTrainees().subscribe( data =>this.arr=data);
    service.getAllTrainees().subscribe( data =>{this.arr = data.body;console.log(data);
    })
  }

  delete(traineeId : number)
  {
    this.service.deleteTraineeById(traineeId).subscribe(data=>this.traine=data);
    //this.service.getAllTrainees().subscribe( data => this.arr=data);
    this.service.getAllTrainees().subscribe( data => this.arr=data.body);
  }

  ngOnInit(): void {
  }

}

