import { Component, OnInit } from '@angular/core';
import { Movies } from '../movies';
import { Observable } from 'rxjs';
import { MovieService } from '../movie.service';


@Component({
  selector: 'app-searchmovie',
  templateUrl: './searchmovie.component.html',
  styleUrls: ['./searchmovie.component.css']
})
export class SearchmovieComponent implements OnInit {

  arr : Movies[]=[];
  movie : Movies = new Movies();
  movies : Observable<Movies[]>;

  ngOnInit(): void {
  }
  
  constructor(private service : MovieService) { }
  find(){
//this.service.findMovieByGenre(this.movie.moviesGenre).subscribe(data=>{this.arr=data,(error: { error: { errorMessage: any; }; })=>alert(error.error.errorMessage)});
    this.movies=this.service.findMovieByGenre(this.movie.moviesGenre);
    
  }
}

  
