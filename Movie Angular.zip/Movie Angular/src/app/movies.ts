export class Movies{
    moviesId : number;
    moviesName : string;
    moviesRating :number;
    moviesGenre : string; 
}