import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddmovieComponent } from './addmovie/addmovie.component';
import { ViewmovieComponent } from './viewmovie/viewmovie.component';
import { SearchmovieComponent } from './searchmovie/searchmovie.component';


const routes: Routes = [
  { path  : 'add',
    component : AddmovieComponent
  },
  {
    path : 'view',
    component : ViewmovieComponent
  },
  {
    path : 'search',
    component : SearchmovieComponent
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
