package com.cg.movie.exception;

public class MovieException extends Exception {

	public MovieException(String message)
	{
		super(message);
	}
	
	public MovieException()
	{
		super();
	}
}
