
package com.cg.movie.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.movie.entity.Movies;
import com.cg.movie.exception.MovieException;
import com.cg.movie.service.MovieService;

@RestController
@CrossOrigin("*")
public class MovieController {

	@Autowired
	MovieService movieService;

	@GetMapping("movies")
	public ResponseEntity<List<Movies>> findAllMovies() throws MovieException {

		List<Movies> list = movieService.findAllMovies();
		ResponseEntity<List<Movies>> rt = new ResponseEntity<List<Movies>>(list, HttpStatus.OK);
		return rt;

	}

	@GetMapping("movies/{genre}")
	public ResponseEntity<List<Movies>> findMovieByGenre(@PathVariable("genre") String moviesGenre) throws MovieException {

		List<Movies> movies = movieService.findMovieByGenre(moviesGenre);
		ResponseEntity<List<Movies>> re = new ResponseEntity<List<Movies>>(movies, HttpStatus.OK);
	
		return re;

	}
	
	
	
	@PostMapping("movies")
	public ResponseEntity<Movies>  createMovies(@RequestBody Movies movies)
	{
		   Movies movies1 = movieService.createMovies(movies);
		   ResponseEntity<Movies> rt= new ResponseEntity<Movies>(movies1,HttpStatus.OK);
		   return rt;
	}

}
