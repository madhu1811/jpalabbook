package com.cg.movie.service;

import java.util.List;

import com.cg.movie.entity.Movies;

import com.cg.movie.exception.MovieException;

public interface MovieService {
	

	public  List<Movies>   findAllMovies() throws MovieException;
    public  List<Movies>  findMovieByGenre(String movieGenre) throws MovieException;
    public Movies createMovies(Movies movies);

}
