package com.cg.movie.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.movie.dao.MovieDao;
import com.cg.movie.entity.Movies;
import com.cg.movie.exception.MovieException;


@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	MovieDao movieDao;
	
	
	@Override
	public List<Movies> findAllMovies() throws MovieException {

		List<Movies> list = movieDao.findAll();
		
		return list;
	}

	@Override
	public List<Movies> findMovieByGenre(String moviesGenre) throws MovieException {

		if( movieDao.findMovieByGenre(moviesGenre)==null)
		{
			throw new MovieException(" No movies with that genre ");
		}
		
		return movieDao.findMovieByGenre(moviesGenre);
	
	}

	@Override
	public Movies createMovies(Movies movies) {
		 Movies  movies1 = movieDao.saveAndFlush(movies);
	     return movies1;
	}

}
