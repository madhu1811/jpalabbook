package com.cg.exception;

public class AuthorException extends Exception {
	
	public AuthorException(String message){
		
		super(message);
	}
	public AuthorException() {
		super();
	}

}
