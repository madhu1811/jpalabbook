import { Component, OnInit } from '@angular/core';
import { Movies } from '../movies';
import { ActivatedRoute, Router } from '@angular/router';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-addmovie',
  templateUrl: './addmovie.component.html',
  styleUrls: ['./addmovie.component.css']
})
export class AddmovieComponent implements OnInit {

  movies : Movies = new Movies();
  temp : Movies = new Movies();
  constructor(private route: ActivatedRoute,private service : MovieService,private router: Router) { }

  ngOnInit(): void {
  }

  createMovies()
  {
    console.log(this.movies);
    this.service.createMovies(this.movies).subscribe(data=>this.temp=data,error=>alert(error.error.errorMessage));
    alert("Added Succesfully");
    this.router.navigate(['view']);
  }

  searchMovie(){
    this.router.navigate(['search']);
  }

}
