import { Component, OnInit } from '@angular/core';

import { Movies } from '../movies';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { MovieService } from '../movie.service';


@Component({
  selector: 'app-viewmovie',
  templateUrl: './viewmovie.component.html',
  styleUrls: ['./viewmovie.component.css']
})
export class ViewmovieComponent implements OnInit {

 
   arr : Observable<Movies[]>;

  constructor(private route: ActivatedRoute,private service : MovieService,private router: Router )
  {
    // service.findAllMovies().subscribe( data =>{this.arr = data.body;console.log(data);})
  }


  ngOnInit(): void {

    this.arr=this.service.findAllMovies();
  }

  add(){
    this.router.navigate(['add']);
  }
}

